package com.sece;
import java.util.Scanner;
import java.sql.SQLException;
import java.io.FileWriter;
import java.io.IOException;

public class Main {

	public static void main(String[] args) throws SQLException, IOException {
		BankingServices accountService = new BankingServices();
		TransactionService transactionService = new TransactionService();
		Scanner scanner = new Scanner(System.in);
		
		while (true) {
            System.out.println("\n1. Admin Login\n2. Customer Login\n3. Logout\n4. Exit");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
			    case 1 -> {
			        System.out.print("Enter Admin Username: ");
			        String adminUser = scanner.nextLine();
			        System.out.print("Enter Admin Password: ");
			        String adminPass = scanner.nextLine();
			        if (accountService.adminLogin(adminUser, adminPass)) {
			            System.out.println("Admin login successful!");
			            adminActions(accountService, transactionService);
			        } else {
			            System.out.println("Invalid admin credentials.");
			        }
			    }
			}
        }
		
	}
	
	private static void adminActions(BankingServices accountService, TransactionService transactionService) throws SQLException, IOException {
        Scanner scanner = new Scanner(System.in);
        while (accountService.isAdminLoggedIn()) {
            System.out.println("\n1. Create Account\n2. Credit Transaction\n3. Withdraw Amount\n4. Transfer Amount\n 5.Get Account Statement");
            System.out.print("Choose an option: ");
            int adminChoice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (adminChoice) {
                case 1 -> accountService.createCustomer();
                case 2 -> {
                    System.out.print("Enter Account ID to Credit: ");
                    int accId = scanner.nextInt();
                    transactionService.performTransaction(accId, "Credit");
                }
                case 3 -> {
                	System.out.print("Enter Account ID to WithDraw: ");
                	int accId = scanner.nextInt();
                	transactionService.performTransaction(accId, "Debit");
                }
                case 4 -> {
                	System.out.println("Enter From Account ID");
                	int fromAccId = scanner.nextInt();
                	transactionService.performTransaction(fromAccId, "Debit");
                	System.out.println("Enter to Account ID");
                	int toAccId = scanner.nextInt();
                	transactionService.performTransaction(toAccId, "Credit");
                }
                case 5 -> {
                	System.out.print("Enter Account ID : ");
                	int accId = scanner.nextInt();
                	transactionService.getAccountStatement(accId);
                }
            }
        }
    }

}
