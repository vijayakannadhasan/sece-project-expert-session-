package com.sece;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;
import java.io.FileWriter;
import java.io.IOException;

public class TransactionService {

    public void performTransaction(int accountId, String transType) throws SQLException, IOException {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter Transaction Amount: ");
        int amount = scanner.nextInt();
        int currentBalance = getCurrentBalance(accountId);

        if (transType.equalsIgnoreCase("Debit") && currentBalance < amount) {
            System.out.println("Insufficient balance!");
            return;
        }

        int newBalance = transType.equalsIgnoreCase("Credit") ? currentBalance + amount : currentBalance - amount;

        String query = "INSERT INTO Transactions (account_id, date, trans_type, trans_amount, acc_balance) VALUES (?, ?, ?, ?, ?)";
        String updateBalanceQuery = "UPDATE Customers SET balance = ? WHERE id = ?";
        
        try (Connection conn = DBConnec.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query);
        	 PreparedStatement pstmtUpdateBalance = conn.prepareStatement(updateBalanceQuery)) {
            pstmt.setInt(1, accountId);
            pstmt.setLong(2, System.currentTimeMillis());
            pstmt.setString(3, transType);
            pstmt.setInt(4, amount);
            pstmt.setInt(5, newBalance);
            pstmt.executeUpdate();
            pstmtUpdateBalance.setInt(1, newBalance);
            pstmtUpdateBalance.setInt(2, accountId);
            pstmtUpdateBalance.executeUpdate();
            System.out.println("Transaction Successful");
            String data = "Amount " + amount + transType + "ed" + " Succesfully to the Account " +  accountId;
            FileWriter write = new FileWriter("transaction101.txt", true);
            write.write(data);
            write.close();
           }
    }

    // Get Current Balance
    private int getCurrentBalance(int accountId) throws SQLException {
        String query = "SELECT balance FROM Customers WHERE id = ?";
        try (Connection conn = DBConnec.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setInt(1, accountId);
            ResultSet rs = pstmt.executeQuery();
            return rs.next() ? rs.getInt("balance") : 0;
        }
    }
    
    public void getAccountStatement(int accountId) throws SQLException, IOException {
    	String query = "SELECT * FROM Transactions WHERE account_id = ?";
    	try (Connection conn = DBConnec.getConnection();
               PreparedStatement pstmt = conn.prepareStatement(query)) {
               pstmt.setInt(1, accountId);
               ResultSet rs = pstmt.executeQuery();
               FileWriter write = new FileWriter("AccountStatementfor " + accountId, true);
               while (rs.next()) {
            	   int transId = rs.getInt("trans_id");
            	   long date = rs.getLong("date");
            	   String transType = rs.getString("trans_type");
            	   int transAmount = rs.getInt("trans_amount");
            	   int accBalance = rs.getInt("acc_balance");
            	   // Format the transaction data
            	   String data = String.format("Transaction ID: %d\nDate: %s\nTransaction Type: %s\nAmount:%d\nBalance: %d\n\n",
            	   transId, date, transType, transAmount, accBalance);
            	   write.write(data);
            	   }

               write.close();
           }
    }
    }
