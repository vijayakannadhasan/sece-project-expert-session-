package com.sece;

import static org.junit.jupiter.api.Assertions.*;

import java.io.IOException;
import java.sql.SQLException;

import org.junit.jupiter.api.Test;

class TransactionServiceTest {
	TransactionService ts = new TransactionService();
	@Test
	public void testGetAccountStatement() throws SQLException, IOException {
		ts.getAccountStatement(6);
	}
	
	@Test
	public void testPerformTransaction() throws SQLException, IOException {
		ts.performTransaction(6, "Credit");
	}
}
