package com.sece;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class BankingServicesTest {

	BankingServices banking = new BankingServices();
	
	@Test
	public void loginWithValidCredentials() {
		boolean result = banking.adminLogin("admin", "admin@123");
		assertEquals(result, true);
	}
	
	@Test 
	public void loginWithInvalidCredentials() {
		boolean result = banking.adminLogin("admin", "admin");
		assertEquals(result, false);
	}

}
